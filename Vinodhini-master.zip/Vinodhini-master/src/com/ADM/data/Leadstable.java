package com.ADM.data;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

public class Leadstable extends JFrame {

	private JPanel contentPane;
	private JTable table;
	Leadsprop lp = new Leadsprop();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Leadstable frame = new Leadstable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Leadstable() {

		setBounds(100, 100, 700, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		try {
			lp.leadvalue();

			int size = lp.lname.length;

			String data[][] = new String[size][5];
			for (int i = 0; i < lp.lname.length; i++)

			{
				data[i][0] = lp.lowner[i];
				data[i][1] = lp.lname[i];
				data[i][2] = lp.lmob[i];
				data[i][3] = lp.lmail[i];
				data[i][4] = lp.lsource[i];
			}

			String columnNames[] = { "leadownername", "lead_name", "mobile", "mail", "leadsource" };

			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 11, 664, 389);
			contentPane.add(scrollPane);

			table = new JTable();
			JTable jt = new JTable(data, columnNames);
			scrollPane.setViewportView(jt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
