package com.ADM.data;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

public class Producttable extends JFrame {

	private JPanel contentPane;
	private JTable table;

	Productprop pp = new Productprop();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Producttable frame = new Producttable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Producttable() {

		setBounds(100, 100, 700, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		try {
			pp.productvalue();

			int size = pp.pname.length;

			String data[][] = new String[size][6];
			for (int i = 0; i < pp.pname.length; i++)

			{
				data[i][0] = pp.pid[i];
				data[i][1] = pp.pname[i];
				data[i][2] = pp.status[i];
				data[i][3] = pp.uprice[i];
				data[i][4] = pp.quantity[i];
				data[i][5] = pp.gsta[i];
			}

			String columnNames[] = { "ProductID", "Product Name", "Status", "Unitprice", "Quantity in Stock", "GST %" };

			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 11, 664, 389);
			contentPane.add(scrollPane);

			table = new JTable();
			JTable jt = new JTable(data, columnNames);
			scrollPane.setViewportView(jt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
